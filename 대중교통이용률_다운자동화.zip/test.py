from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

import time
import os

# 다운로드 경로 설정

year=1
area=1
month=1
try:
    while True:
        download_dir = os.path.abspath("downloads")
        options = webdriver.ChromeOptions()
        prefs = {
            "download.default_directory": download_dir,  # 다운로드 폴더 지정
            "download.prompt_for_download": False,       # 다운로드 시 팝업 비활성화
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        }
        options.add_experimental_option("prefs", prefs)
        options.add_argument("--headless")  # 헤드리스 모드 설정
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")

        # 드라이버 초기화
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        wait = WebDriverWait(driver, 20)
        url = "https://stcis.go.kr/pivotIndi/wpsPivotIndicator.do?siteGb=P&indiClss=IC05&indiSel=IC0507"
        driver.get(url)
        element = driver.find_element(By.XPATH, "//li[@class='searchDateGubun' and @value='2']")
        element.click()
        time.sleep(6)
        driver.find_element(By.XPATH, '//*[@id="date2"]/li[1]/img').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="ui-datepicker-div"]/div[1]/div/select[1]').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="ui-datepicker-div"]/div[1]/div/select[1]/option[{year}]').click()
        time.sleep(1)
        driver.find_element(By.XPATH, f'//*[@id="ui-datepicker-div"]/div[1]/div/select[2]').click()
        time.sleep(1)
        driver.find_element(By.XPATH, f'//*[@id="ui-datepicker-div"]/div[1]/div/select[2]/option[{month}]').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="ui-datepicker-div"]/div[2]/button').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="searchZoneSd"]').click()
        time.sleep(1)
        driver.find_element(By.XPATH, f'//*[@id="searchZoneSd"]/option[{area+1}]').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="divSgg"]/ol/li[1]/label/div').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="divChkDmn"]/li[2]/label/div').click()
        time.sleep(1)
        driver.find_element(By.XPATH, f'//*[@id="btnSearch"]/button').click()
        time.sleep(2)
        driver.find_element(By.XPATH, f'//*[@id="btnExport"]').click()
        time.sleep(4)
        driver.quit()
        # 다운로드한 파일 경로 및 새 파일 이름 설정
        original_file = os.path.join(download_dir, "응용 지표(대중교통 이용인원)_20241010.xlsx") 
        file_name=f"year_{year+2017}_month_{month}_area_{area}.xlsx"
        new_file = os.path.join(download_dir, file_name)  # 새로운 파일명
        os.rename(original_file, new_file)
        
        
        if(year>7) :
            break
        else:
            month+=1
        if(month>12):
            month=1
            area+=1
            if(area>17):
                year+=1
                area=1
        

    
    
finally:

    driver.quit()